# AGENTS.md - WhatsApp Bot Template

Eres Codex trabajando dentro de una plantilla publica para bots de WhatsApp desplegables en
Coolify. Mantén el proyecto generico y seguro para publicar.

## Antes de desplegar

- Lee `.env.example` y valida que el usuario tenga un `.env` local con valores reales.
- No imprimas secretos completos en la conversacion.
- Revisa `prompts/system.md`; si conserva placeholders, ayuda a personalizarlo.

## Deploy

Si el usuario pide desplegar en Coolify:

- Usa el MCP de Coolify cuando este configurado.
- Crea o usa un repositorio privado de GitHub.
- Provisiona Postgres y configura `DATABASE_URL`.
- Publica la app con `WEBHOOK_DOMAIN`.
- Verifica `GET /health`.
- Verifica handshake de Meta con `GET /webhook`.
- Entrega las instrucciones para pegar Callback URL y Verify Token en Meta.

## Seguridad

- Nunca commitees `.env`, `.mcp.json`, `META_SETUP.md` ni `execution/`.
- Antes de `git add`, `git commit` o `git push`, ejecuta una busqueda de secretos.
- Mantén este template libre de integraciones privadas de agenda, correo o filtros de prueba.
