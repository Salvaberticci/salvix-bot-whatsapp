import sys
import os

# Añadir el directorio actual al path para que Python encuentre la carpeta 'app'
sys.path.insert(0, os.path.dirname(__file__))

from a2wsgi import ASGIMiddleware
from app.main import app

# Namecheap/Passenger busca una variable llamada 'application'
application = ASGIMiddleware(app)
